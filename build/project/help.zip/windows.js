
var _d2hWindowParamsByWindows = null;
function d2hInitWindowParams()
{
	if (_d2hWindowParamsByWindows == null)
	{
		_d2hWindowParamsByWindows = new Array();

		_d2hWindowParamsByWindows["d2hWnd_proc"] = "left=680,top=10,height=500,width=315,resizable=1,scrollbars=1";

	}
}
