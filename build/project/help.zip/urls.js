var g_ContentsURL = "5_2%20KFS%20User%20Documentation-toc.htm";
var g_IndexURL = "5_2%20KFS%20User%20Documentation-index.htm";
var g_SearchURL = "5_2%20KFS%20User%20Documentation-search.htm";
var g_FavoritesURL = "5_2%20KFS%20User%20Documentation-favorites.htm";
