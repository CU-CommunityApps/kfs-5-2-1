var g_ContentsURL = "KFS%20User%20Documentation-toc.htm";
var g_IndexURL = "KFS%20User%20Documentation-index.htm";
var g_SearchURL = "KFS%20User%20Documentation-search.htm";
var g_FavoritesURL = "KFS%20User%20Documentation-favorites.htm";
